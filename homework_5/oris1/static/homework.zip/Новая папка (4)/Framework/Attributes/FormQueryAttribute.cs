﻿namespace oris.Framework.Attributes
{
    [AttributeUsage(AttributeTargets.Parameter)]
    public class FormQueryAttribute : Attribute
    {
    }
}